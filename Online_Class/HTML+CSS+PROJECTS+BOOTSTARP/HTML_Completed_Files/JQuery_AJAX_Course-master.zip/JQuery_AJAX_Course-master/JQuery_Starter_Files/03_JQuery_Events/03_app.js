/*
    1) Click Event for a button BS Styles
    2) dblClick event for a button BS Styles
    3) Hover on an Image with opacity
    4) Focus Event & blur Event
    5) MouseEnter Event to show a BS Modal
 */