// If Else condition Example


// For loop Example to display from 1 - 10 values


// While loop Example to display from 1 - 10 values


// Do while loop Example to display from 1 - 10 values


// Switch Statement Example
