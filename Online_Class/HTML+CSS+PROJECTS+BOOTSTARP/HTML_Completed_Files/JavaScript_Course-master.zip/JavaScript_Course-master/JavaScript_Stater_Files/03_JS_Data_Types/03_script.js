// number example

// String Examples

// boolean Examples

// reassignment example of variables
