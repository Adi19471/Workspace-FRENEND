// creation of arrays


// Accessing an array and its properties


// Access not existed property from an array


// adding properties to an array


// Accessing length of an Array


// reverse the array using reverse()


// Remove the first value of the array: shift()


// Add value to front of the array:unshift()


// Remove the last value of the array: pop()


// Add value the end of the array: push()


// Remove an element from an Array , Arguments: colors.splice(pos,n):


// Create a copy of an array. Typically assigned to a new variable:slice();


// indexOf()


// join() , split()



// MDN documentation for Array:
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array
