//console log

//Display date on the console

// Display date on the web page using DOM