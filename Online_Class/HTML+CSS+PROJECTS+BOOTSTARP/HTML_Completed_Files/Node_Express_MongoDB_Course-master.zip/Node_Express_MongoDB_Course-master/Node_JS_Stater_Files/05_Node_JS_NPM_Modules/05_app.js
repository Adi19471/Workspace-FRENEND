/*
    lodash Module
 */